﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.IO;
using System.Text.RegularExpressions;
using System.ComponentModel;
using System.Net.Http;
using System.Text;
using System.Xml;

namespace WebsiteScrapper.Business
{
    public class AppSettings
    {
        public string SkipDomains { get; set; }
    }
}