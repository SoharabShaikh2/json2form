﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.IO;
using System.Text.RegularExpressions;
using System.ComponentModel;
using System.Net.Http;
using System.Text;
using System.Xml;

namespace WebsiteScrapper.Business
{
    public class Constants
    {
        public static readonly string[] arrAvoidExtensions = { ".pdf", ".jpg", ".jpeg", ".png", ".gif", ".xml" }; //extensions to skip during html web requests 
        public static readonly string[] arrStaticExtensions = { ".html", ".js", ".css", ".ico", ".pdf", ".jpg", ".jpeg", ".png", ".gif", ".xml" }; //extensions to skip during html web requests 
        //public static readonly string[] arrSkipDomains = { "google", "googleapis", "bootstrap", "jquery" }; //extensions to skip during html web requests 
    }
}