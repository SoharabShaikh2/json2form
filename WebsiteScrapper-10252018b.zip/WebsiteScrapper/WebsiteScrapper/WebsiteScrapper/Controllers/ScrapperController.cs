﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using WebsiteScrapper.Business;
using WebsiteScrapper.Model;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

using System.Net;
using System.IO;

namespace WebsiteScrapper.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ScrapperController : ControllerBase
    {
        readonly string DirectoryPath;
        static string[] SkipDomains;
        AppSettings _AppSettings { get; set; }
        readonly ILogger<ScrapperController> _log;//logger instance to track logging
        public ScrapperController(ILogger<ScrapperController> log, IOptions<AppSettings> settings)
        {
            _log = log;
            _AppSettings = settings.Value;
            DirectoryPath = Directory.GetCurrentDirectory() + "\\AppData\\";
            //DirectoryPath = "E:\\scrapper\\";
        }
        // GET api/scrapper
        [HttpGet]
        public ActionResult<String> Get(string SiteName, string SiteUrl, string SameDomain)
        {
            try
            {
                _log.LogInformation(" |VDS: Start| ");//logging start
                SkipDomains = _AppSettings.SkipDomains.Split(',');
                if (string.IsNullOrEmpty(SiteName) || string.IsNullOrEmpty(SiteUrl) || string.IsNullOrEmpty(SameDomain))
                {
                    return "Website details not provided";//returned empty if required parameters are missing
                }

                Start(SiteUrl, SameDomain, SiteName);// load reponse from scrapper class

                return "Website scrapping process initiated"; //return calculated output
            }
            catch (Exception ex)
            {
                _log.LogError(string.Join("||", " - Exceptin in Start -  "
                            , "SiteName=" + SiteName
                            , "SiteUrl=" + SiteUrl
                            , "SameDomain=" + SameDomain
                            , ex.Message));
                return "Some error occured while processing request";
            }
        }

        // POST api/scrapper
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/scrapper/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/scrapper/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }

        public void Start(string SiteUrl, string SameDomain, string SiteName)
        {

            String WebsiteUrl = string.Empty;
            String WebsiteName = string.Empty;
            bool _SameDomain = true;

            WebsiteName = SiteName;
            WebsiteUrl = SiteUrl;
            _SameDomain = SameDomain.ToLower().Equals("true");
            if (!Directory.Exists(DirectoryPath + WebsiteName))
            {
                Directory.CreateDirectory(DirectoryPath + WebUtility.UrlDecode(WebsiteName));
            }

            LinkParam oLinkParam = new LinkParam();
            SiteUrl = SiteUrl.ToLower();// converted site url to lower case to avoid any url mismatch

            Uri uri = new Uri(SiteUrl);// created site uri to get domain

            GetLinkParams(SiteUrl, uri.Scheme, uri.Host, true, out oLinkParam);

            //DownloadCss(_SameDomain, uri.Scheme, uri.Host, oLinkParam, DirectoryPath + WebsiteName);

            DownloadHtml(oLinkParam.AbsoluteUrl, WebsiteUrl, WebsiteName, _SameDomain, uri.Scheme, uri.Host);
        }
        public void DownloadHtml(string SiteUrl, string WebsiteUrl, string WebsiteName, bool SameDomain, string Scheme, string Host)
        {
            LinkParam oLinkParam = new LinkParam();

            GetLinkParams(SiteUrl, Scheme, Host, true, out oLinkParam);
            if (oLinkParam.Skip)
            {
                return;
            }
            bool Process = false;// to calculate if system needs to crawl page or not, default set to false

            if (SameDomain)
            {
                if (oLinkParam.AbsoluteUrl.Contains(Host))// if same domain is set ture and request is coming from same domain then set process variable to true
                    Process = true;
            }
            else { Process = true; }// if same domain is not true then set process is true
            if (Process)
            {
                foreach (var ext in Constants.arrAvoidExtensions)// checked allowed extensions before making requests
                {
                    if (oLinkParam.AbsoluteUrl.Contains(ext))
                        Process = false;
                }
            }

            if (!System.IO.File.Exists(DirectoryPath + WebsiteName + oLinkParam.FilePath) && Process)// if all checkes are passed and page is not already crawled then process
            {
                try
                {
                    string aTag = "(?<=<a.+href=(?:'|\"))[^'\"]*?(?=(?:'|\"))";// regex to fetch anchor tags
                    string scripts = "(?<=<script.+src=(?:'|\"))[^'\"]*?(?=(?:'|\"))";// regex to fetch script tags
                    string images = "(?<=<img.+src=(?:'|\"))[^'\"]*?(?=(?:'|\"))";// regex to fetch image tags
                    string css = "(?<=<link.+href=(?:'|\"))[^'\"]*?(?=(?:'|\"))";// regex to fetch css tags

                    string bgimages = "background(.*?)url(?:\\(['\"]?)(.*?)(?:['\"]?\\))"; // regex to fetch images in background css

                    List<string> lATag;// list to store links on all pages
                    List<string> lScripts;// list to store scripts on all pages
                    List<string> lImages;// list to store images on all pages
                    List<string> lCss;// list to store style sheets on all pages

                    List<string> lBGImages;// 


                    List<string> AllLinks = new List<string>();
                    WebClient client = new WebClient();
                    try
                    {
                        //check and create folder if it does not exist
                        if (!Directory.Exists(DirectoryPath + WebsiteName + WebUtility.UrlDecode(oLinkParam.FolderPath)))
                        {
                            Directory.CreateDirectory(DirectoryPath + WebsiteName + WebUtility.UrlDecode(oLinkParam.FolderPath));
                        }

                        WebRequest oWebRequest;
                        WebResponse oWebResponse;

                        oWebRequest = WebRequest.Create(oLinkParam.AbsoluteUrl);// created web request
                        //oWebRequest.Headers.Add("User-Agent", "Mozilla/5.0");
                        oWebRequest.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36");
                        oWebResponse = oWebRequest.GetResponse();// made web request

                        Stream streamResponse = oWebResponse.GetResponseStream();// load response of web request

                        StreamReader sreader = new StreamReader(streamResponse);// stream reader object to read the output stream

                        string response = sreader.ReadToEnd();// saved response to a string veriable

                        ////load html of the downloaded file to the veriable
                        //using (System.IO.StreamReader sr = new System.IO.StreamReader(DirectoryPath + WebsiteName + oLinkParam.FilePath))
                        //{
                        //    response = sr.ReadToEnd();
                        //}

                        //regex to remove all the commented code from html
                        response = Regex.Replace(response, "<!--.*?-->", string.Empty, RegexOptions.Singleline);

                        lATag = GetLinks(response, aTag);// calculated anchor tags from response
                        lScripts = GetLinks(response, scripts);// calculated script tags from response
                        lImages = GetLinks(response, images);// calculated image tags from response
                        lCss = GetLinks(response, css);// calculated css tags from response

                        lBGImages = GetLinks(response, bgimages);// calculated 

                        lATag.RemoveAll(a => a.Contains("tel:"));// removed anchor tags with for telephone
                        lATag.RemoveAll(a => a.Contains("mailto:"));// removed anchor tags with for mailto
                        lATag.RemoveAll(a => a.Contains("skype:"));// removed anchor tags with for skype
                        lATag.RemoveAll(a => a.Contains("javascript:"));// removed anchor tags with for javascript

                        lATag.Distinct().ToList().ForEach(a => AllLinks.Add(Regex.Replace(a, @"(?<=#)[^.]*", "").Replace("#", "")));// removed # tags from urls
                        AllLinks = AllLinks.Distinct().ToList();// calculated distinct for final results

                        lScripts = lScripts.Distinct().ToList();// calculated distinct for final results
                        lImages = lImages.Distinct().ToList();// calculated distinct for final results
                        lCss = lCss.Distinct().ToList();// calculated distinct for final results

                        LinkParam olp = new LinkParam();

                        foreach (var v in lImages)
                        {
                            if (!string.IsNullOrEmpty(v))
                            {
                                GetLinkParams(v, Scheme, Host, false, out olp);
                                if (!olp.Skip)
                                {
                                    response = response.Replace("\"" + v + "\"", "\"" + olp.FilePath.Replace("\\", "/") + "\"");
                                    response = response.Replace("'" + v + "'", "'" + olp.FilePath.Replace("\\", "/") + "'");
                                    if (!System.IO.File.Exists(DirectoryPath + WebsiteName + olp.FilePath))
                                    {
                                        DownloadStaticContent(Host, DirectoryPath + WebsiteName, false, olp);
                                    }
                                }
                            }
                        }
                        foreach (var v in lScripts)
                        {
                            if (!string.IsNullOrEmpty(v))
                            {
                                GetLinkParams(v, Scheme, Host, false, out olp);
                                if (!olp.Skip)
                                {
                                    response = response.Replace("\"" + v + "\"", "\"" + olp.FilePath.Replace("\\", "/") + "\"");
                                    response = response.Replace("'" + v + "'", "'" + olp.FilePath.Replace("\\", "/") + "'");
                                    if (!System.IO.File.Exists(DirectoryPath + WebsiteName + olp.FilePath))
                                    {
                                        DownloadStaticContent(Host, DirectoryPath + WebsiteName, false, olp);
                                    }
                                }
                            }
                        }
                        foreach (var v in lCss)
                        {
                            if (!string.IsNullOrEmpty(v))
                            {
                                if (v.ToLower().Contains(".css"))
                                {
                                    GetLinkParams(v, Scheme, Host, true, out olp);
                                    if (!olp.Skip)
                                    {
                                        response = response.Replace("\"" + v + "\"", "\"" + olp.FilePath.Replace("\\", "/") + "\"");
                                        response = response.Replace("'" + v + "'", "'" + olp.FilePath.Replace("\\", "/") + "'");


                                        if (!System.IO.File.Exists(DirectoryPath + WebsiteName + olp.FilePath))
                                        {
                                            //DownloadStaticContent(Host, DirectoryPath + WebsiteName, false, olp);
                                            DownloadCss(SameDomain, Scheme, Host, olp, DirectoryPath + WebsiteName);

                                        }
                                    }
                                }
                            }
                        }
                        string url = string.Empty;
                        foreach (var v in lBGImages)
                        {
                            if (!string.IsNullOrEmpty(v))
                            {
                                url = v.Substring(v.IndexOf("url(") + 4, v.IndexOf(")") - v.IndexOf("url(") - 4).Replace("'", "").Replace("\"", "");
                                GetCssLinkParams(url, Scheme, Host, true, out olp, oLinkParam);
                                if (!olp.Skip)
                                {
                                    response = response.Replace(url, olp.FilePath.Replace("\\", "/"));
                                    //response = response.Replace("\"" + url + "\"", "\"" + olp.FilePath.Replace("\\", "/") + "\"");
                                    //response = response.Replace("'" + url + "'", "'" + olp.FilePath.Replace("\\", "/") + "'");
                                    if (!System.IO.File.Exists(DirectoryPath + WebsiteName + olp.FilePath))
                                    {
                                        DownloadStaticContent(Host, DirectoryPath + WebsiteName, false, olp);
                                    }
                                }
                            }
                        }
                        LinkParam olp1 = new LinkParam();
                        bool anchorHtml;
                        foreach (var v in AllLinks)
                        {

                            if (olp.FileName != olp.PageUrlName)
                            {
                                response = response.Replace("\"" + v + "\"", "\"" + olp.FilePath.Replace("\\", "/") + "\"");
                                response = response.Replace("'" + v + "'", "'" + olp.FilePath.Replace("\\", "/") + "'");
                            }
                            anchorHtml = false;
                            if (!string.IsNullOrEmpty(v))
                            {
                                foreach (var ext in Constants.arrAvoidExtensions)// checked allowed extensions before making requests
                                {
                                    if (v.Contains(ext))
                                        anchorHtml = true;
                                }
                                if (anchorHtml)
                                {
                                    GetLinkParams(v, Scheme, Host, false, out olp);
                                    if (!olp.Skip)
                                    {
                                        if (!System.IO.File.Exists(DirectoryPath + WebsiteName + olp.FilePath))
                                        {
                                            DownloadStaticContent(Host, DirectoryPath + WebsiteName, false, olp);
                                        }
                                    }
                                }
                                else
                                {
                                    GetLinkParams(v, Scheme, Host, true, out olp1);

                                    if (olp1.FileName != olp1.PageUrlName)
                                    {
                                        response = response.Replace("\"" + v + "\"", "\"" + olp1.FilePath.Replace("\\", "/") + "\"");
                                        response = response.Replace("'" + v + "'", "'" + olp1.FilePath.Replace("\\", "/") + "'");
                                    }

                                    Task.Factory.StartNew(() =>
                                    {
                                        DownloadHtml(v, WebsiteUrl, WebsiteName, SameDomain, Scheme, Host);
                                    });
                                }
                            }
                        }

                        ////replaced links of the 
                        //foreach (var v in AllLinks)
                        //{
                        //    if (!string.IsNullOrEmpty(v))
                        //    {
                        //        GetLinkParams(v, Scheme, Host, true, out olp);
                        //        if (olp.FileName != olp.PageUrlName)
                        //        {
                        //            response = response.Replace("\"" + v + "\"", "\"" + olp.FilePath.Replace("\\", "/") + "\"");
                        //            response = response.Replace("'" + v + "'", "'" + olp.FilePath.Replace("\\", "/") + "'");
                        //        }
                        //    }
                        //}

                        if (!System.IO.File.Exists(DirectoryPath + WebsiteName + oLinkParam.FilePath))
                        {
                            //System.IO.File.Delete(DirectoryPath + WebsiteName + oLinkParam.FilePath);
                            System.IO.File.WriteAllText(DirectoryPath + WebsiteName + oLinkParam.FilePath, response);
                        }
                    }
                    catch (Exception ex)
                    {
                        _log.LogError(string.Join("||", " - DownloadHtmlError -  "
                                    , "SiteUrl=" + SiteUrl
                                    , "AbsoluteUrl=" + oLinkParam.AbsoluteUrl
                                    , "FileName=" + oLinkParam.FileName
                                    , "FilePath=" + oLinkParam.FilePath
                                    , "FolderPath=" + oLinkParam.FolderPath
                                    , "PageUrlName=" + oLinkParam.PageUrlName
                                    , ex.Message));
                    }
                }
                catch (Exception ex)
                {
                    _log.LogError(ex, " |DownloadHtml| " + ex.Message);

                }
            }
        }
        public void SaveFile(string FilePath, string content)
        {
            try
            {
                using (System.IO.StreamWriter file =
    new System.IO.StreamWriter(FilePath, true))
                {
                    file.Write(content);
                }
            }
            catch (Exception ex)
            {
                _log.LogError(ex, " |SaveFile| " + ex.Message);

            }
        }
        public static void GetLinkParams(string RawLink, string Scheme, string Domain,
                bool isHtml, out LinkParam oLinkParam)
        {
            string AbsoluteUrl, PageUrlName, FileName, FilePath, FolderPath;
            oLinkParam = new LinkParam();
            FileName = string.Empty;
            FilePath = string.Empty;
            FolderPath = string.Empty;
            AbsoluteUrl = string.Empty;
            PageUrlName = string.Empty;
            foreach (var domain in SkipDomains)// check static extensions before making requests
            {
                if (RawLink.ToLower().Contains("." + domain + ".") ||
                    RawLink.ToLower().Contains("//" + domain + "."))
                {
                    oLinkParam.Skip = true;
                    return;
                }
            }

            if (RawLink.StartsWith("//"))// check if url is absolute or just page name
            {
                RawLink = Scheme + ":" + RawLink;
            }
            if (RawLink.StartsWith("http://") || RawLink.StartsWith("https://"))// check if url is absolute or just page name
            {
                if (RawLink.Replace("http://", "").Replace("https://", "").Replace("/", "")
                    == Domain)
                {
                    AbsoluteUrl = Scheme + "://" + Domain;// + "index.html";
                }
                else
                {
                    AbsoluteUrl = RawLink;// + "index.html";
                }
            }
            else
                AbsoluteUrl = Scheme + "://" + (Domain + "/" + RawLink).Replace("//", "/");

            Uri SiteUri = new Uri(AbsoluteUrl);

            AbsoluteUrl = SiteUri.AbsoluteUri;

            PageUrlName = SiteUri.Segments[SiteUri.Segments.Length - 1].Replace("/", "");

            bool isStatic = false;
            bool skipQS = false;
            string sExtension = ".html";
            foreach (var ext in Constants.arrStaticExtensions)// check static extensions before making requests
            {
                if (PageUrlName.ToLower().Contains(ext))
                {
                    isStatic = true;
                    sExtension = ext;
                    skipQS = true;
                }
            }

            if (isHtml && !isStatic)
            {
                FileName = PageUrlName.Split('.')[0];
            }
            else
                FileName = PageUrlName;

            if (isHtml && string.IsNullOrEmpty(FileName))
                FileName = "index.html";

            string[] ar11 = SiteUri.OriginalString.Replace("https://", "").Replace("http://", "").Replace(Domain, "").Trim('/').Split('/');

            for (int i = 0; i < ar11.Length; i++)
            {
                if (i + 1 < ar11.Length)
                {
                    if (!string.IsNullOrEmpty(ar11[i]))
                        FolderPath += "\\" + ar11[i];
                }
                else if (!string.IsNullOrEmpty(ar11[i]))
                {
                    if (isHtml && ar11[i].Contains("?"))
                    {
                        if (skipQS)
                        {
                            FileName = ar11[i].Split('?')[0];
                        }
                        else
                        {
                            string[] ar = ar11[i].Split('?')[1].Split('&');
                            foreach (string str1 in ar)
                            {
                                if (!string.IsNullOrEmpty(str1))
                                {
                                    string[] ar2 = str1.Split('=');
                                    if (ar2.Length == 2)
                                    {
                                        FileName += "-" + ar2[1].Replace(" ", "-");
                                    }
                                }
                            }
                        }
                    }

                }
            }
            if (isHtml)
                FileName = FileName.Replace(sExtension, "") + sExtension;
            FilePath = (FolderPath + "\\" + FileName).Replace("\\\\", "\\");

            oLinkParam.FileName = WebUtility.UrlDecode(FileName);
            oLinkParam.FilePath = WebUtility.UrlDecode(FilePath);
            oLinkParam.FolderPath = WebUtility.UrlDecode(FolderPath);
            oLinkParam.AbsoluteUrl = WebUtility.UrlDecode(AbsoluteUrl);
            oLinkParam.PageUrlName = WebUtility.UrlDecode(PageUrlName);

        }

        public static void GetCssLinkParams(string RawLink, string Scheme, string Domain,
                bool isHtml, out LinkParam oLinkParam, LinkParam inLinkParam)
        {
            string AbsoluteUrl, PageUrlName, FileName, FilePath, FolderPath;
            oLinkParam = new LinkParam();
            FileName = string.Empty;
            FilePath = string.Empty;
            FolderPath = string.Empty;
            AbsoluteUrl = string.Empty;
            PageUrlName = string.Empty;
            foreach (var domain in SkipDomains)// check static extensions before making requests
            {
                if (RawLink.ToLower().Contains("." + domain + ".") ||
                    RawLink.ToLower().Contains("//" + domain + "."))
                {
                    oLinkParam.Skip = true;
                    return;
                }
            }

            if (RawLink.StartsWith("//"))// check if url is absolute or just page name
            {
                RawLink = Scheme + ":" + RawLink;
            }
            if (RawLink.StartsWith("http://") || RawLink.StartsWith("https://"))// check if url is absolute or just page name
            {
                if (RawLink.Replace("http://", "").Replace("https://", "").Replace("/", "")
                    == Domain)
                {
                    AbsoluteUrl = Scheme + "://" + Domain;// + "index.html";
                }
                else
                {
                    AbsoluteUrl = RawLink;// + "index.html";
                }
            }
            else
                AbsoluteUrl = Scheme + "://" + (Domain + "/" + RawLink).Replace("//", "/");

            Uri SiteUri = new Uri(AbsoluteUrl);

            AbsoluteUrl = SiteUri.AbsoluteUri;

            PageUrlName = SiteUri.Segments[SiteUri.Segments.Length - 1].Replace("/", "");

            bool isStatic = false;
            bool skipQS = false;
            string sExtension = ".html";
            foreach (var ext in Constants.arrStaticExtensions)// check static extensions before making requests
            {
                if (PageUrlName.ToLower().Contains(ext))
                {
                    isStatic = true;
                    sExtension = ext;
                    skipQS = true;
                }
            }

            if (isHtml && !isStatic)
            {
                FileName = PageUrlName.Split('.')[0];
            }
            else
                FileName = PageUrlName;

            if (isHtml && string.IsNullOrEmpty(FileName))
                FileName = "index.html";

            string[] ar11 = SiteUri.OriginalString.Replace("https://", "").Replace("http://", "").Replace(Domain, "").Trim('/').Split('/');

            for (int i = 0; i < ar11.Length; i++)
            {
                if (i + 1 < ar11.Length)
                {
                    if (!string.IsNullOrEmpty(ar11[i]))
                        FolderPath += "\\" + ar11[i];
                }
                else if (!string.IsNullOrEmpty(ar11[i]))
                {
                    if (isHtml && ar11[i].Contains("?"))
                    {
                        if (skipQS)
                        {
                            FileName = ar11[i].Split('?')[0];
                        }
                        else
                        {
                            string[] ar = ar11[i].Split('?')[1].Split('&');
                            foreach (string str1 in ar)
                            {
                                if (!string.IsNullOrEmpty(str1))
                                {
                                    string[] ar2 = str1.Split('=');
                                    if (ar2.Length == 2)
                                    {
                                        FileName += "-" + ar2[1].Replace(" ", "-");
                                    }
                                }
                            }
                        }
                    }

                }
            }
            if (isHtml)
                FileName = FileName.Replace(sExtension, "") + sExtension;
            FilePath = (FolderPath + "\\" + FileName).Replace("\\\\", "\\");

            if (FolderPath.Contains(".."))
            {
                string[] ard = FolderPath.Split("..");
                string temp = AbsoluteUrl;
                AbsoluteUrl = string.Empty;

                string[] absUrl = inLinkParam.AbsoluteUrl.Split("/");
                for (int i = 0; i < absUrl.Length - (ard.Length); i++)
                {
                    AbsoluteUrl += absUrl[i] + "/";
                }
                AbsoluteUrl += temp.Replace(Scheme + "://" + Domain + "/", "");
                FolderPath = FolderPath.Replace("..\\", "");
                FilePath = FilePath.Replace("..\\", "");
            }

            oLinkParam.FileName = WebUtility.UrlDecode(FileName);
            oLinkParam.FilePath = WebUtility.UrlDecode(FilePath);
            oLinkParam.FolderPath = WebUtility.UrlDecode(FolderPath);
            oLinkParam.AbsoluteUrl = WebUtility.UrlDecode(AbsoluteUrl);
            oLinkParam.PageUrlName = WebUtility.UrlDecode(PageUrlName);

        }

        public void DownloadStaticContent(String Host, string RootPath, bool SameDomain, LinkParam oLinkParam)
        {
            try
            {
                bool Process = false;// to calculate if system needs to crawl page or not, default set to false

                if (SameDomain)
                {
                    if (oLinkParam.AbsoluteUrl.Contains(Host))// if same domain is set ture and request is coming from same domain then set process variable to true
                        Process = true;
                }
                else { Process = true; }// if same domain is not true then set process is true

                if (Process)
                {
                    if (!System.IO.File.Exists(RootPath + oLinkParam.FilePath))
                    {
                        if (!Directory.Exists(RootPath + oLinkParam.FolderPath))
                        {
                            Directory.CreateDirectory(RootPath + WebUtility.UrlDecode(oLinkParam.FolderPath));
                        }
                        Task.Factory.StartNew(() =>
                        {
                            try
                            {
                                if (!System.IO.File.Exists(RootPath + oLinkParam.FilePath))
                                {
                                    String lsResponse = string.Empty;
                                    //if (oLinkParam.AbsoluteUrl.StartsWith("http://") || oLinkParam.AbsoluteUrl.StartsWith("https://"))
                                    //{
                                    HttpWebRequest hwRequest = (HttpWebRequest)WebRequest.Create(oLinkParam.AbsoluteUrl);
                                    hwRequest.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36");
                                    //hwRequest.Headers.Add("User-Agent", "Mozilla/5.0");
                                    // returned values are returned as a stream, then read into a string

                                    using (HttpWebResponse hwResponse = (HttpWebResponse)hwRequest.GetResponse())
                                    {
                                        using (BinaryReader reader = new BinaryReader(hwResponse.GetResponseStream()))
                                        {
                                            if (!System.IO.File.Exists(RootPath + oLinkParam.FilePath))
                                            {
                                                Byte[] lnByte = reader.ReadBytes(10485760);
                                                using (FileStream lxFS = new FileStream(RootPath + WebUtility.UrlDecode(oLinkParam.FilePath), FileMode.Create))
                                                {
                                                    lxFS.Write(lnByte, 0, lnByte.Length);
                                                }
                                            }
                                        }
                                    }
                                    //}
                                    //else
                                    //{
                                    //    FileWebRequest fwRequest = (FileWebRequest)WebRequest.Create(oLinkParam.AbsoluteUrl);
                                    //    fwRequest.Headers.Add("User-Agent", "Mozilla/5.0");
                                    //    // returned values are returned as a stream, then read into a string

                                    //    using (FileWebResponse fwResponse = (FileWebResponse)fwRequest.GetResponse())
                                    //    {
                                    //        using (BinaryReader reader = new BinaryReader(fwResponse.GetResponseStream()))
                                    //        {
                                    //            if (!System.IO.File.Exists(RootPath + oLinkParam.FilePath))
                                    //            {
                                    //                Byte[] lnByte = reader.ReadBytes(10485760);
                                    //                using (FileStream lxFS = new FileStream(RootPath + WebUtility.UrlDecode(oLinkParam.FilePath), FileMode.Create))
                                    //                {
                                    //                    lxFS.Write(lnByte, 0, lnByte.Length);
                                    //                }
                                    //            }
                                    //        }
                                    //    }
                                    //}
                                    //WebClient client = new WebClient();
                                    //client.DownloadFile(oLinkParam.AbsoluteUrl, RootPath + WebUtility.UrlDecode(oLinkParam.FilePath));
                                }
                            }
                            catch (Exception ex)
                            {
                                // no need to log exception for static content as there could be multiple threads trying 
                                // to same same file simultaneously, file will be stored by the first process
                                // _log.LogError(string.Join("||", " - DownloadStaticContent -  ", ex.Message, ex.StackTrace));
                            }
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                _log.LogError(ex, " |DownloadStaticContent| " + ex.Message);
            }
        }

        public List<string> GetLinks(string content, string regX)
        {
            Regex regexLink = new Regex(regX);// created regex to get required tags

            List<string> Links = new List<string>();// created list to hold urls/links
            foreach (var match in regexLink.Matches(content))// matched patter and stored results to list
            {
                if (!Links.Contains(match.ToString()))
                    Links.Add(match.ToString());
            }

            return Links;
        }

        public void DownloadCss(bool SameDomain, string Scheme, string Host, LinkParam oLinkParam, string RootPath)
        {
            if (oLinkParam.Skip)
            {
                return;
            }
            bool Process = false;// to calculate if system needs to crawl page or not, default set to false

            if (SameDomain)
            {
                if (oLinkParam.AbsoluteUrl.Contains(Host))// if same domain is set ture and request is coming from same domain then set process variable to true
                    Process = true;
            }
            else { Process = true; }// if same domain is not true then set process is true
            if (Process)
            {
                foreach (var ext in Constants.arrAvoidExtensions)// checked allowed extensions before making requests
                {
                    if (oLinkParam.AbsoluteUrl.Contains(ext))
                        Process = false;
                }
            }

            if (Process)// if all checkes are passed and page is not already crawled then process
            {
                try
                {
                    if (!System.IO.File.Exists(RootPath + oLinkParam.FilePath))
                    {
                        //check and create folder if it does not exist
                        if (!Directory.Exists(RootPath + WebUtility.UrlDecode(oLinkParam.FolderPath)))
                        {
                            Directory.CreateDirectory(RootPath + WebUtility.UrlDecode(oLinkParam.FolderPath));
                        }
                        try
                        {
                            if (!System.IO.File.Exists(RootPath + oLinkParam.FilePath))
                            {
                                string bgimages = "background(.*?)url(?:\\(['\"]?)(.*?)(?:['\"]?\\))"; // regex to fetch images in background css

                                List<string> lBGImages;// 

                                WebClient client = new WebClient();
                                try
                                {
                                    WebRequest oWebRequest;
                                    WebResponse oWebResponse;

                                    oWebRequest = WebRequest.Create(oLinkParam.AbsoluteUrl);// created web request
                                                                                            //oWebRequest.Headers.Add("User-Agent", "Mozilla/5.0");
                                    oWebRequest.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36");
                                    oWebResponse = oWebRequest.GetResponse();// made web request

                                    Stream streamResponse = oWebResponse.GetResponseStream();// load response of web request

                                    StreamReader sreader = new StreamReader(streamResponse);// stream reader object to read the output stream

                                    string response = sreader.ReadToEnd();// saved response to a string veriable

                                    lBGImages = GetLinks(response, bgimages);// calculated 

                                    LinkParam olp = new LinkParam();
                                    string url = string.Empty;
                                    foreach (var v in lBGImages)
                                    {
                                        if (!string.IsNullOrEmpty(v))
                                        {
                                            url = v.Substring(v.IndexOf("url(") + 4);
                                            url = url.Substring(0, url.IndexOf(")")).Replace("'", "").Replace("\"", "");
                                            if (url.ToLower().EndsWith(".png")
                                                || url.ToLower().EndsWith(".jpeg")
                                                || url.ToLower().EndsWith(".gif")
                                                || url.ToLower().EndsWith(".jpg")
                                                || url.ToLower().EndsWith(".bmp"))
                                            {
                                                GetCssLinkParams(url, Scheme, Host, true, out olp, oLinkParam);
                                                if (!olp.Skip)
                                                {
                                                    response = response.Replace(url, olp.FilePath.Replace("\\", "/"));
                                                    if (!System.IO.File.Exists(RootPath + olp.FilePath))
                                                    {
                                                        DownloadStaticContent(Host, RootPath, false, olp);
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    if (!System.IO.File.Exists(RootPath + oLinkParam.FilePath))
                                    {
                                        System.IO.File.WriteAllText(RootPath + oLinkParam.FilePath, response);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    _log.LogError(string.Join("||", " - DownloadCss -  "
                                                , "AbsoluteUrl=" + oLinkParam.AbsoluteUrl
                                                , "FileName=" + oLinkParam.FileName
                                                , "FilePath=" + oLinkParam.FilePath
                                                , "FolderPath=" + oLinkParam.FolderPath
                                                , "PageUrlName=" + oLinkParam.PageUrlName
                                                , ex.Message));
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            // no need to log exception for static content as there could be multiple threads trying 
                            // to same same file simultaneously, file will be stored by the first process
                            // _log.LogError(string.Join("||", " - DownloadStaticContent -  ", ex.Message, ex.StackTrace));
                        }
                    }

                }
                catch (Exception ex)
                {
                    _log.LogError(ex, " |DownloadCss| " + ex.Message);
                }
            }
        }
    }
}
