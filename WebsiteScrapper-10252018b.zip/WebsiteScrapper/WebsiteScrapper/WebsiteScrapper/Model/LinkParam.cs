﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace WebsiteScrapper.Model
{
    public class LinkParam
    {
        public string AbsoluteUrl;
        public string PageUrlName;
        public string FileName;
        public string FilePath;
        public string FolderPath;
        public bool Skip;
    }
}