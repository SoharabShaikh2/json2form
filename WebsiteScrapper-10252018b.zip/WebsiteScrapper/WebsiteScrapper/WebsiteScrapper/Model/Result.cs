﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace WebsiteScrapper.Model
{
    public class Result
    {
        public string PageUrl;
        public List<string> Anchors;
        public List<string> Images;
        public List<string> Styles;
        public List<string> Scripts;
    }
}